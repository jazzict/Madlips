<html>
<head>
  <title>Formulier</title>
  <link href="style1.css" rel="stylesheet" type="text/css" />
</head>

<body>

<h1> Mad Lips </h1>
<div class="all">
<ul>
  <li> <a href="http://localhost/form.php">Er heerst paniek.. </a></li>
  <li><a href="http://localhost/onkunde.php">Onkunde </a></li>
</ul>
 <h2> Onkunde </h2>
  <form method="post" action="index1.php">
    <p>
      <label>Wat zou je graag willen kunnen?</label>
      <input type="text" name="kunnen" />
    </p>
    
    <p>
      <label>Met welke persoon kun je goed opschieten?</label>
      <input type="text" name="persoon" />
    </p>

    <p>
      <label>Wat is je favoriete getal?</label>
      <input type="text" name="getal" />
    </p>

    <p>
      <label>Wat heb je altijd bij als je op vakantie gaat?</label>
      <input type="text" name="vakantie" />
    </p>

    <p>
      <label>Wat is je beste persoonlijke eigenschap?</label>
      <input type="text" name="beste" />
    </p>

    <p>
      <label>Wat is je slechtste persoonlijke eigenschap?</label>
      <input type="text" name="slechtste" />
    </p>

    <p>
      <label>Wat is het ergste dat je kan overkomen?</label>
      <input type="text" name="overkomen" />
    </p>

    <label>&nbsp;</label>
    <p>
      <input type="submit" value="Versturen" />
    </p>
    </div>
  </form>
</body>
</html>
